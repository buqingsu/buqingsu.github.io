import pytest
import requests
import json

BASE_URL = "http://localhost:8000"

def test_login_success():
    data = {"user_phone": "12345678911", "passwd": "123456"}
    response = requests.post(f"{BASE_URL}/api/login", json=data)
    assert response.status_code == 200

def test_get_weather():
    params = {"city": "南京"}
    response = requests.get(f"{BASE_URL}/api/weather", params=params)
    assert response.status_code == 200
